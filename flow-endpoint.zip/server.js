import express from "express";
const app = express();

app.use(express.json());

// Health check route
app.get("/", (req, res) => {
  res.send("Health check OK");
});

// WhatsApp Flow endpoint (this is what Meta will call)
app.post("/webhook", (req, res) => {
  console.log("Flow data:", req.body);
  res.status(200).send("Received");
});

// Start server
app.listen(3000, () => {
  console.log("Server running on port 3000");
});
